The MIM Skin
--------------------

INSTALLATION
------------
Copy this module to /config/modules/custom/skins directory.
Add to one of your modules xml files as so:

<module name="mim" dir="custom/skins/mim" permissionlevel="public" />

DEVELOPMENT
--------------------

Read more about altering this in its internal folder

repository
--------------------

This skin is a custom skin commissioned by MIM and lives here:

https://github.com/sweco-dkbesr/sps-skin-mim

CHANGES
--------------------
Date        Description
2020-12-29  Created

